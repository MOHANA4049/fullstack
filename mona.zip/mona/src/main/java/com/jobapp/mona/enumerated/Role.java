package com.jobapp.mona.enumerated;

public enum Role {
    ADMIN,USER
}
