package com.jobapp.mona;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MonaApplicationTests {

	@Test
	void contextLoads() {
	}

}
